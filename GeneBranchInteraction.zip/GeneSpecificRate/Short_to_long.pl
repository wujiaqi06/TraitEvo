#!/usr/bin/env perl -w
# (Copyright) Jiaqi Wu
use diagnostics;
use 5.010;
use strict;
use Cwd;
use Getopt::Std;

my %opts;
getopts('i:o:', \%opts);
my $input_file = $opts{'i'} or die "use: perl $0 -i input_table -o output_table\n";
my $output_file = $opts{'o'} or die "use: perl $0 -i input_table -o output_table\n";


my @distance_table = &read_file("$input_file");
my @branch = split (/\s/, $distance_table[0]);
shift @branch;
open OUTPUT, ">./$output_file";

foreach my $i (@distance_table){
	my @line = split (/\s+/, $i);
	#print "@line";
	foreach my $j (0..($#line-1)){
		print OUTPUT "$line[0]\t$branch[$j]\t$line[$j+1]\n";
	}
}

sub read_file{
	open INPUT, "@_" or die "Can not open file: @_";
	my @file;
	while (<INPUT>){
		chomp;
		s/\r//;
		push @file, $_;
	}
	close INPUT;
	@file;
}
