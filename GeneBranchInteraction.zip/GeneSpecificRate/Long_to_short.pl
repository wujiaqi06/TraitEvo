#!/usr/bin/env perl -w
# (Copyright) Jiaqi Wu
use diagnostics;
use 5.010;
use strict;
use Cwd;
use Getopt::Std;


my %opts;
getopts('i:o:', \%opts);
my $input_file = $opts{'i'} or die "use: $0 -i input_table -o output_table\n";
my $output_table = $opts{'o'} or die "use: $0 -i input_table -o output_table\n";

my @table = &read_file("$input_file");

open RRARE, ">./$output_table" or die "Cannot make file: $!\n";

my %table;
my @genes;
my @branch;
foreach my $i (@table){
	my @lines = split(/\s+/, $i);
	my $name = "$lines[0]"."_"."$lines[1]";
	$table{$name} = $lines[2];
	push @genes, $lines[0];
	push @branch, $lines[1];
	#print "$lines[2]\n";
}
@genes = &uniq(@genes);
@branch = &uniq(@branch);

print RRARE "Annotation\t";
foreach my $i (@branch){
	print RRARE "$i\t";
}
print RRARE "\n";

foreach my $i (@genes){
	print RRARE "$i\t";
	foreach my $j (@branch){
		my $name = "$i"."_"."$j";
		#print "$name\n";
		print RRARE "$table{$name}\t";
	}
	print RRARE "\n";
}



sub read_file{
	open INPUT, "@_" or die "Can not open file: @_";
	my @file;
	while (<INPUT>){
		chomp;
		push @file, $_;
	}
	close INPUT;
	@file;
}

sub uniq{
	my %seen;
	return grep {!$seen{$_}++} @_;
}
