####Read Data and screening genes
read.table("tree_length_sum.out",header=F)->tree
hist(tree[,2],nclass=30,main="",col=4,xlab="total branch length")
head(tree)
read.table("alpha_sum.out",header=F)->data0
head(data0)
alpha <- data0[,2]
hist(alpha,nclass=50,main="Histogram of genes",col=4,xlab="alpha value")
data0[alpha>1,]
read.table("branch_length.matrix.out",header=T)->branch0
branch0[1:5,1:5];dim(branch0)
names(branch0)
branch <- branch0[,paste("B",1:176,sep="")]
rownames(branch) <- branch0[,1]
branch[1:5,1:5];dim(branch)
tot_BL <- apply(branch,1,sum)
max_BL <- apply(branch,1,max)
threshold1 <- 1.7
threshold2 <- 20
branch <- branch[max_BL<threshold1&tot_BL<threshold2,]; dim(branch)
branch[1:5,1:5];


tot_BL <- apply(branch,1,sum)
max_BL <- apply(branch,1,max)
par(mfcol=c(1,2))
hist(tot_BL)
hist(max_BL)
par(mfcol=c(1,1))

short_to_long <- function(input_matrix){
  rownames(input_matrix) -> rowname
  colnames(input_matrix) -> colname
  pairwise_table <- c()
  for (i in 1:length(rowname)){
    for (j in 1:length(colname)){
      cbind(rowname[i],colname[j],input_matrix[i,j]) -> line0
      rbind(pairwise_table,line0) -> pairwise_table
    }
  }
  return (pairwise_table)
}

long_to_short <- function (input_matrix,clo_number){
  col1_name = unique(input_matrix[,1])
  col2_name = unique(input_matrix[,2])
  output_matrix <- c()
  for (i in (1:length(col1_name))){
    lines <- c()
    for (j in (1:length(col2_name))){
      lines <- cbind(lines,input_matrix[(i-1)*length(col2_name)+j,clo_number])
    }
    output_matrix <- rbind(output_matrix,lines)
  }
  rownames(output_matrix) <- col1_name
  colnames(output_matrix) <- col2_name
  return (output_matrix)
}

branch1 <- cbind (Anno = rownames(branch),branch);dim(branch1);branch1[1:5,1:5]
write.table(branch1, file = "branch_length.matrix.screen.txt", quote = F, sep = "\t", col.names = T, row.names = F)
system ("perl Short_to_long.pl -i branch_length.matrix.screen.txt -o branch_length.table.screen.txt")
read.table("branch_length.table.screen.txt", header = F) -> branch.data;head(branch.data)
##An alternative way, but very very slow
#short_to_long(branch) -> branch.data;dim(branch.data) ## Very slow

branch.data <- branch.data[-c(1:176),];head(branch.data)
colnames(branch.data) <- c("gene","branch","BL")
branch.data <- data.frame(branch.data)### Why I can not directly run lm model?
write.table(branch.data, "branch_length_long_table_screen.txt", quote = F,row.names = F)
read.table("branch_length_long_table_screen.txt",header=T)->branch.data;dim(branch.data)


read.table("pep_length_sum.out",header=F)->seq.length;dim(seq.length)
### Subfunction for selecting screened data.
select_data <- function(input_matrix1, input_matrix2){
  selected_gene <- rownames(input_matrix1)
  selected_matrix2 <- c()
  for (i in 1:length(selected_gene)){
    for (j in 1:nrow(input_matrix2)){
      if (input_matrix2[j,1] == selected_gene[i]){
        selected_matrix2 <- rbind(selected_matrix2, input_matrix2[j,])
      } 
    }
  }
  return (selected_matrix2)
}
###


#####################################################
head(branch.data)
head(seq.length);nrow(seq.length)
branch_list <- unique(branch.data[,2]);head(branch_list)
seq.length <- select_data(branch,seq.length);head(seq.length);dim(seq.length)
#write.table(seq.length, "seq_length_selected.txt", quote = F, row.names = F, col.names = T, sep = "\t")
branch[1:5,1:5]
get_event <- function(input_matrix, seq_length){
  event <- c()
  row_name <- rownames(input_matrix)
  for (i in (1:length(row_name))){
    for (j in (1:nrow(seq_length))){
      if (row_name[i] == seq_length[j,1]){
        event <- rbind(event,input_matrix[i,]*seq_length[j,2])
      }
    }
  }
  return (event)
}

event <- get_event(branch, seq.length)
event1 <- cbind (Anno = rownames(event),event);dim(event1);event1[1:5,1:5]
write.table(event1, file = "event.matrix.screen.txt", quote = F, sep = "\t", col.names = T, row.names = F)
system ("perl Short_to_long.pl -i event.matrix.screen.txt -o event.matrix.table.txt")
read.table("event.matrix.table.txt", header = F) -> event.table
event.table <- event.table[-c(1:176),];head(event.table)

#event.table <- short_to_long(event)
head(event.table);dim(event.table)
colnames(event.table) <- c("gene","branch","event")
#write.table(event.table, "event_table_long_selected.txt", quote = F, row.names = F, col.names = T)
#read.table("event_table_long_selected.txt",header = T) -> event.table
head(event.table);dim(event.table)
##### Add Sequence Length information
colnames(seq.length) <- c("gene","1")
seq.length0  <- c()
seq.length0 <- seq.length
for (i in 2:176){
  seq.length0 <- cbind(seq.length0,i = seq.length[,2])
}
dim(seq.length0);seq.length0[1:5,1:5]
#seq.length1 <- c(Anno = rownames(branch),seq.length0);seq.length1[1:5,1:5]
write.table(seq.length0, "length.test.txt", quote = F, row.names = F, col.names = F, sep = "\t")
system ("perl Short_to_long.pl -i length.test.txt -o length.test.long.txt")
read.table ("length.test.long.txt", header = F) -> seq.length0; dim(seq.length0)
seq.length0[170:180,]
colnames(seq.length0) <- c("gene", "seq.length0","seq.length");head(seq.length0)
######

branch.data2 <- data.frame(brancch.data,events = event.table$event,seq.length = seq.length0[,3])
write.table (branch.data2, "BL_events_rrate_long_SL.txt", quote = F, row.names = F)
read.table("BL_events_rrate_long_SL.txt", header = T) -> branch.data2
dim(branch.data2)
head(branch.data2)
## Very Slow
branch.pois <- glm(events ~ offset(log(seq.length)) + gene + branch,poisson,data=branch.data2)
branch.pois.predict <- predict(branch.pois,type="response")
##
names(branch.pois)
rate0 <- branch.data2$events/branch.pois.predict
head(branch.data2)
par(mfrow=c(1,2))
plot (rate0,branch.data2$rrate)
plot (branch.data2$event, branch.pois.predict)
par(mfrow=c(1,1))
branch.data2 <- data.frame(branch.data,events = event.table$event,seq.length = seq.length0[,3],rate.pois = rate0)
head(branch.data2)
#read.table("BL_events_rrate_long_SL_rate.pois.txt", header = T) -> branch.data2;head(branch.data2)
#####
rate.pois.matrix <- long_to_short(branch.data2, 6)
rate.pois.matrix.trans <- t(rate.pois.matrix)
write.table (rate.pois.matrix, "rate.pois.matrix.txt", quote = F, row.names = T)
write.table (rate.pois.matrix.trans, "rate.pois.matrix.screen.trans.txt", quote = F, row.names = F)

