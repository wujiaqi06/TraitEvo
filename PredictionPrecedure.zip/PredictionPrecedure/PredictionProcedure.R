library(glmnet)
library(ROCR)
library(minpack.lm)
library(ape)

####Read1185GeneRate
read.table("rate.pois.matrix.txt") -> rate.pois.allgene.trait;dim(rate.pois.allgene.trait)## Prediction Data
#write.table (t(rate.pois.allgene.trait), file = "rate.posi.matrix.trans.txt",sep = "\t",quote = F)
terminal.nodes <- scan("terminal.nodes.txt", "character", sep = " ")
internal.nodes <- scan("Internal.nodes.txt", "character", sep = " ")
trait <- read.table("TraitStates.txt")
trait.term <- trait[,c(1:10)];colnames(trait.term);dim(trait.term)
rate <- t(rate.pois.allgene.trait);colnames(rate)[1:10];dim(rate)
rate.term <- rate[terminal.nodes,]
colnames(rate.term)[1:10];dim(rate.term)
BestNSample <- c(225, 145, 400, 145, 205, 350, 195, 195, 200, 215);length(BestNSample)####Best sample size for solitary
########Read1185GeneRate

trait.for.test <- c(1:10)
BestNSample <- BestNSample[trait.for.test]
trait.test <- trait.term[,trait.for.test];dim(trait.test);colnames(trait.test)

################nearest neighbour###############################
read.tree("Mam_Timetree_Rate.nwk") -> time.tree
cophenetic(time.tree) -> distance1;distance1[1:5,1:5]
distance1[,order(colnames(distance1))] -> distance1
distance1[order(rownames(distance1)),] -> distance1
distance0 <- distance1

near.neighbour <- function(trait,distance,alpha){
  x <- rep(0,length(trait))
  for (j in 1:length(x)){
    x[j] <- sum(trait[-j]/distance[-j,j]^alpha)/sum(1/distance0[-j,j]^alpha)
  }
  return (x)
}

xlogy <- function(x,y){
  if (y>0){
    z = x*log(y)
  } else {
    z = x * (-10^10)
  }
  z
}
xlogy(1,0)

KL <- function(x, y){
  return (-sum(xlogy(x,y))-sum(xlogy(1-x,1-y)))
}


########################################################################
#####
par(mfcol=c(4,3))
cutoff.traits <- c()
triat.accuracy <- c()
trait.recall <- c()
trait.Fpr <- c()
trait.Spec <- c()
leave.one.out.accuracy <- c()
leave.one.out.cutoff <- c()
coeff.traits <- c()
all.gene.internal <- c()
cut <- c(0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5);length(cut)
all.pre <- c()
legend.all <- c()

for (i in 1:length(trait)) #for (i in 6:10)
{
  trait0 <- trait.term[trait.term[,i] != 0.5,];dim(trait0)
  trait0.test <- trait.term[trait.term[,i] != 0.5,i]
  ########################################################Pred.By.Allgenes
  rate00 <- as.data.frame(rate.term[trait.term[,i] != 0.5,]);dim(rate00)
  p0 <- mean(trait0.test)
  score0 <- abs((trait0.test - p0) %*% as.matrix(rate00))
  #hist(score0)
  gene0 <- order(score0,decreasing=T)
  rate01 <- rate00[,gene0[1:BestNSample[i]]]
  gene.list <- gene0[1:BestNSample[i]]
  rate.pois.rate01 <- rate[,gene.list]
  
  trait01.cv.glmnet <- cv.glmnet(x=as.matrix(rate01),trait0.test,family="binomial",nfolds = length(trait0.test))
  trait01.lambda.min <- trait01.cv.glmnet$lambda.min
  trait01.glmnet <- glmnet(x=as.matrix(rate01),trait0.test,lambda=trait01.lambda.min,"binomial")
  trait01.coef <- trait01.glmnet$beta
  allgene.coef <- as.matrix(trait01.coef)
  #write.table(allgene.coef, file = paste(colnames(trait0)[i],".Allgene.coef.txt",sep=""),quote=F,sep="\t")
  #plot(trait01.cv.glmnet,main=colnames(trait0)[i])
  #plot(trait0.coef,ylab = "trait.coef",type="h",col=2,main=colnames(trait0)[i])
  trait01.predict <- predict(trait01.glmnet,newx=as.matrix(rate01),type="response")
  data.pred <- prediction(trait01.predict,trait0.test)
  data.perf3 <- performance(data.pred, measure="acc", x.measure="cutoff")
  bestAccInd <- which.max(data.perf3@"y.values"[[1]])
  data.pref4 <- performance(data.pred, measure = "acc", x.measure = "rec")
  trait_accuracy <- data.perf3@"y.values"[[1]][bestAccInd]
  BestRecall <- which.max(data.pref4@"y.values"[[1]])
  trait_recall <-  data.pref4@"y.values"[[1]][BestRecall]
  trait_error <- 1- trait_accuracy
  trait_error.cut <- round(trait_error, digits = 3)
  trait.mis_class.rate <- 1- trait_accuracy
  trait.mis_class.rate.cut <- round(trait.mis_class.rate,digits = 3)
  trait.cutoff <- round(data.perf3@"x.values"[[1]][bestAccInd], 4)
  rbind(cutoff.traits,trait.cutoff) -> cutoff.traits
  data.pred4 <- performance(data.pred,"rec")
  
  leave_one_pred2 <- c()
  for (j in 1: length(trait0.test)){
    leave_one.trait = trait0.test[j]
    leave_one.rate = rate01[j,]
    remain.trait = trait0.test[-j]
    remain.rate = rate01[-j,]
    trait.remain.cv.glmnet <- cv.glmnet(x=as.matrix(remain.rate),remain.trait,family="binomial",nfolds = length(remain.trait))
    trait.remain.lambda.min <- trait.remain.cv.glmnet$lambda.min
    trait.remain.glmnet <- glmnet(x=as.matrix(remain.rate),remain.trait,lambda=trait.remain.lambda.min,"binomial")
    trait.test.coef <- trait.remain.glmnet$beta
    one.pred <- predict(trait.remain.glmnet,newx=as.matrix(leave_one.rate),type="response")
    rbind(leave_one_pred2, one.pred) -> leave_one_pred2
  }
  #write.table(leave_one_pred2, file = paste(colnames(trait0)[i],".loocPre.txt",sep=""),quote=F,sep="\t")
  data.all.pred <- prediction(leave_one_pred2,trait0.test)
  data.all.perf3 <- performance(data.all.pred, measure="acc", x.measure="cutoff")
  bestAccInd <- which.max(data.all.perf3@"y.values"[[1]])
  leave_one_out2_accuracy <- data.all.perf3@"y.values"[[1]][bestAccInd]
  mis_class.rate <- 1- leave_one_out2_accuracy
  leave_one_out2_accuracy.cut <- round(leave_one_out2_accuracy, digits = 3)
  mis_class.rate.cut <- round(mis_class.rate,digits=3)
  cutoff <- round(data.all.perf3@"x.values"[[1]][bestAccInd], 4)
  data.all.perf <- performance(data.all.pred,"tpr","fpr")
  data.all.auc <- performance(data.all.pred,"auc")
  data.all.auc <- unlist(slot(data.all.auc, "y.values"))
  data.all.auc <- round(data.all.auc,digits = 3)
  data.all.pref4 <- performance(data.all.pred , measure = "acc", x.measure = "rec")
  BestRecall <- which.max(data.all.pref4@"y.values"[[1]])
  data.all_recall <-  data.all.pref4@"x.values"[[1]][BestRecall]
  recall <- c()
  cbind(colnames(trait)[i],paste("RR recall ",data.all_recall)) -> recall
  
  data.all.pref5 <- performance(data.all.pred , measure = "acc", x.measure = "fpr")
  BestFpr <- which.max(data.all.pref5@"y.values"[[1]])
  data.all_Fpr <-  data.all.pref5@"x.values"[[1]][BestFpr]
  Fpr <- c()
  cbind(colnames(trait)[i],paste("RR fpr ",data.all_Fpr)) -> Fpr
  
  data.all.pref5 <- performance(data.all.pred , measure = "acc", x.measure = "spec")
  BestSpec <- which.max(data.all.pref5@"y.values"[[1]])
  data.all_Spec <-  data.all.pref5@"x.values"[[1]][BestSpec]
  Spec <- c()
  cbind(colnames(trait)[i],paste("RR Spec ",data.all_Spec)) -> Spec

  accuracy <- c()
  cbind(colnames(trait)[i],paste("RR accuracy ",leave_one_out2_accuracy)) -> accuracy
  
  
  ###############################prediction_By_nearest_neighbour
  nearest.neighbour1 <- c()
  distance1 <-  distance0[trait.term[,i] != 0.5,trait.term[,i] != 0.5]
  for (s in 1:length(trait0.test)){
    alpha <- seq(0, 30, by = 0.1)
    KL.nn <- c()
    #t <- 2
    for (t in 1:length(alpha)){
      trait.nn <- near.neighbour(trait0.test[-s], distance1[-s,-s], alpha[t])
      KL.nn <- c(KL.nn,KL(trait0.test[-s],trait.nn))
    }
    order (KL.nn)[1] -> alpha.index0
    nearest.neighbour.leave.one <- near.neighbour(trait0.test,distance1,alpha[alpha.index0])
    nearest.neighbour1 <- c(nearest.neighbour1,nearest.neighbour.leave.one[s]) 
  }
  
  pred.nearestNB <- prediction(nearest.neighbour1,trait0.test)
  pred.nearestNB.perf3 <- performance(pred.nearestNB, measure="acc", x.measure="cutoff")
  bestAccInd <- which.max(pred.nearestNB.perf3@"y.values"[[1]])
  pred.nearestNB_accuracy <- pred.nearestNB.perf3@"y.values"[[1]][bestAccInd]
  pred.nearestNB_error <- 1- pred.nearestNB_accuracy
  pred.nearestNB_error.cut <- round(pred.nearestNB_error, digits = 3)
  pred.nearestNB_auc <- performance(pred.nearestNB,"auc")#,fpr.stop=0.5)
  pred.nearestNB_auc <- unlist(slot(pred.nearestNB_auc, "y.values"))
  pred.nearestNB_auc <- round(pred.nearestNB_auc,digits = 3)
  pred.nearestNB.pref4 <- performance(pred.nearestNB , measure = "acc", x.measure = "rec")
  pred.nearestNB.pref4_BestRecall <- which.max(pred.nearestNB.pref4@"y.values"[[1]])
  pred.nearestNB.pref4_recall <-  pred.nearestNB.pref4@"x.values"[[1]][pred.nearestNB.pref4_BestRecall]
  cbind(recall,paste("NN recall ",pred.nearestNB.pref4_recall)) -> recall
  trait.recall <- rbind(trait.recall, recall)
  nearest.neighbour1 <- data.frame(nearest.neighbour1)
  rownames(nearest.neighbour1) <- rownames(trait0)
  #write.table(nearest.neighbour1, file = paste(colnames(trait0)[i],".nnPre.txt",sep=""),quote=F,sep="\t")
 
  pred.nearestNB.pref5 <- performance(pred.nearestNB , measure = "acc", x.measure = "fpr")
  pred.nearestNB.pref5_BestFpr <- which.max(pred.nearestNB.pref5@"y.values"[[1]])
  pred.nearestNB.pref5_Fpr <-  pred.nearestNB.pref5@"x.values"[[1]][pred.nearestNB.pref5_BestFpr]
  
  cbind(Fpr,paste("NN Fpr ",pred.nearestNB.pref5_Fpr)) -> Fpr
  trait.Fpr <- rbind(trait.Fpr, Fpr)
  
  pred.nearestNB.pref6 <- performance(pred.nearestNB , measure = "acc", x.measure = "spec")
  pred.nearestNB.pref6_BestSpec <- which.max(pred.nearestNB.pref6@"y.values"[[1]])
  pred.nearestNB.pref6_Spec <-  pred.nearestNB.pref6@"x.values"[[1]][pred.nearestNB.pref6_BestSpec]
  
  cbind(Spec,paste("NN Spec ",pred.nearestNB.pref6_Spec)) -> Spec
  trait.Spec <- rbind(trait.Spec, Spec)
  
  cbind(accuracy,paste("NN accuracy ",pred.nearestNB_accuracy)) -> accuracy
  rbind(triat.accuracy,accuracy) -> triat.accuracy
  
  pred.nearestNB.perf <- performance(pred.nearestNB,"tpr","fpr")
  #plot(trait0.test~nearest.neighbour1, main=colnames(trait0)[i], xlab = paste("nearest.neighbour, error = ",pred.nearestNB_error.cut))
  
  
  legend.pre <- c(colnames(trait0)[i],paste("Phy AUC = ", pred.nearestNB_auc), paste("All AUC = ", data.all.auc, sep=""))
  legend.all <- rbind(legend.all,legend.pre)
  ###########prediction by internal nodes ##################
  
  #plot(nearest.neighbour1,trait0.test,
  #     xlab="predicted probability",ylab="observed",
  #     main=paste(colnames(trait)[i], " Phylo"))
  #abline(v=leave_one_out2_accuracy.cut, col = "red")
  
  plot(data.all.perf,main=colnames(trait0)[i],col = "red")
  plot(pred.nearestNB.perf, add = TRUE, col="blue")
  
  pre.internal <- predict(trait01.glmnet,newx=as.matrix(rate.pois.rate01),type="response")
  trait.miss <- rownames(trait.term[trait.term[,i] == 0.5,])
  pre.miss <- predict(trait01.glmnet,newx=as.matrix(rate.pois.rate01[trait.miss,]),type="response")
  #write.table (pre.miss, file = paste(colnames(trait)[i], "Miss.txt", sep="."),quote=F, sep="\t")
  all.gene.internal <- cbind(all.gene.internal,pre.internal)
  
} 
colnames(legend.all) <- c("Trait", "RelativeRate", "NearestNeighbour")
legend.all
rownames(cutoff.traits) <- colnames(trait.term)
cutoff.traits
par(mfcol=c(1,1)) 
legend.all   ##AUC 
triat.accuracy
trait.recall ##Sensity
trait.Fpr 
trait.Spec ### Specificity

